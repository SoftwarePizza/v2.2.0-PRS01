/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2022 Presta.Site
 * @license   LICENSE.txt
 */
 $(document).ready(function() {
var result = setInterval(function() {
      $('.ttproductcountdown.buttons_bottom_block').each(function(){
        var time = $(this).attr('data-to');

        var countDownDate = new Date(time.replace(/ /g,"T")+'Z');
        var now = new Date().getTime();
    
        var distance = countDownDate - now;
        
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        var data = days + '' + hours + '' + minutes + '' + seconds + '';

        $(this).find('.time .days').html(days);
        $(this).find('.time .hours').html(hours);
        $(this).find('.time .minutes').html(minutes);
        $(this).find('.time .seconds').html(seconds);
        $(this).find('.complated').hide();

        if (distance < 0) {
          clearInterval(x);
          data =  "complate";
          $(this).find('.time').hide();
          $(this).find('.product-timer-complate').show(data);
        }
      });
        
    }, 1000);
});
