<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ttpopupnewsletter}prestashop>ttpopupnewsletter_c0702b61402d0955a4cfe861efb13c54'] = 'Ingrese su correo ...';
$_MODULE['<{ttpopupnewsletter}prestashop>ttpopupnewsletter_b26917587d98330d93f87808fc9d7267'] = 'Suscribir';
$_MODULE['<{ttpopupnewsletter}prestashop>ttpopupnewsletter_a87408b0f38547f2a6eefaca4049b18f'] = 'No volver a mostrar esta ventana emergente';
