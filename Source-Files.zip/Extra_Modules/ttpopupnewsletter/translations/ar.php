<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ttpopupnewsletter}prestashop>ttpopupnewsletter_c0702b61402d0955a4cfe861efb13c54'] = 'أدخل بريدك ...';
$_MODULE['<{ttpopupnewsletter}prestashop>ttpopupnewsletter_b26917587d98330d93f87808fc9d7267'] = 'الإشتراك';
$_MODULE['<{ttpopupnewsletter}prestashop>ttpopupnewsletter_a87408b0f38547f2a6eefaca4049b18f'] = 'لا تظهر هذه النافذة المنبثقة مرة أخرى';
