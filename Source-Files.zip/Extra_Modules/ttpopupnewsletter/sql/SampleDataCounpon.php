<?php
/**
 * 2010-2022 
 *
 * NOTICE OF LICENSE
 *
 * DISCLAIMER
 *

 *  @author    templatetrip <support@templatetrip.com>
 *  @copyright 2010-2022 templatetrip
 *  @license   http://www.templatetrip.com
 */

class SampleDataCounpon
{
	public function initData()
	{
		$return = true;
		$languages = Language::getLanguages(true);
		$id_shop = Configuration::get('PS_SHOP_DEFAULT');
		
		$return &= Db::getInstance()->Execute('INSERT IGNORE INTO `'._DB_PREFIX_.'ttpopupnewsletter` (`id_ttpopupnewsletter`, `cookies_time`, `active`) VALUES 
		(1, 864000, 1);
		');
		
		$return &= Db::getInstance()->Execute('INSERT IGNORE INTO `'._DB_PREFIX_.'ttpopupnewsletter_shop` (`id_ttpopupnewsletter`, `id_shop`, `cookies_time`, `active`) VALUES 
		(1, "'.$id_shop.'", 864000, 1);
		');
		
		
		$tt_title = 'NEWSLETTER';
		
		$text = '<div class="innerbox-newsletter"><div class="newsletter-text"><p>Subscribe to the Complex mailing list to receive updates on new arrivals, special offers, and other discount information</p></div></div>';
		
		foreach ($languages as $language)
		{
			$return &= Db::getInstance()->Execute('INSERT IGNORE INTO `'._DB_PREFIX_.'ttpopupnewsletter_lang` (`id_ttpopupnewsletter`, `id_shop`, `id_lang`, `tt_title`, `content`, `background`) VALUES 
			(1, "'.$id_shop.'", "'.$language['id_lang'].'",\''.$tt_title.'\', \''.$text.'\', "newsletter.jpg");
			');
		}
		return $return;
	}
}
?>