<?php
/**
 * 2010-2022 
 *
 * NOTICE OF LICENSE
 *
 * DISCLAIMER
 *

 *  @author    templatetrip <support@templatetrip.com>
 *  @copyright 2010-2022 templatetrip
 *  @license   http://www.templatetrip.com
 */

/**
* In some cases you should not drop the tables.
* Maybe the merchant will just try to reset the module
* but does not want to loose all of the data associated to the module.
*/

$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ttpopupnewsletter_lang`';
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ttpopupnewsletter_shop`';
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ttpopupnewsletter`';

foreach ($sql as $query)
	if (Db::getInstance()->execute($query) == false)
		return false;
