/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2022 Presta.Site
 * @license   LICENSE.txt
 */
$(document).ready(function () {

	if ($.cookie("ttpopupnewsletter") != "true") {

$("#ttPopupnewsletter").modal({show: true});

		$(".send-reqest").click(function(){

			var email = $("#ttnewsletter-input").val();

			$.ajax({
				type: "POST",
				headers: { "cache-control": "no-cache" },
				async: false,
				url: field_path,
				data: "name=marek&email="+email,
				dataType: "jsonp",
				jsonp: 'callback',
				success: function(data) {
					if (data)
						$(".ttAlert").html(data);
					}
			});

		});

		$('#ttnewsletter-input').keypress(function(event){

		  var keycode = (event.keyCode ? event.keyCode : event.which);

		  if (keycode == '13') {
					var email = $("#ttnewsletter-input").val();
					$.ajax({
						type: "POST",
						headers: { "cache-control": "no-cache" },
						async: false,
						url: field_path,
						data: "name=marek&email="+email,
						dataType: "jsonp",
						jsonp: 'callback',
						success: function(data) {
							if (data)
								$(".ttAlert").html(data);
							}
					});

					event.preventDefault();

		  }

		});

                $("#tt_tick_dont_show").prop("checked") == false;

	}



	$('#tt_tick_dont_show').change(function(){

	    if($(this).is(':checked')){

		$.cookie("ttpopupnewsletter", "true");

	    }else{

		$.cookie("ttpopupnewsletter", "false");

	    }

	});



});