/**
 * 2010-2022 
 *
 * NOTICE OF LICENSE
 *
 * DISCLAIMER
 *

 *  @author    templatetrip <support@templatetrip.com>
 *  @copyright 2010-2022 templatetrip
 *  @license   http://www.templatetrip.com
 */

$(document).ready(function()
{
	$(document).on('click', '.open .tt-coupon-small, .open .share-coupon-small-wrapper', function()
	{
		showDialog();
	});
	$(document).on('click', '.close .tt-coupon-small, .close .share-coupon-small-wrapper', function()
	{
		closeDialog(cookies_time);
	});
});

function showDialog()
{  
	var data={'task':'showPopup'};
		$.ajax({
		type: "POST",
		cache: false,
		url: tt_coupon_url + '/front-end-ajax.php',
		dataType : "json",
		data: data,
		complete: function(){},
		success: function (response) {
			console.log(response);
		}
	}); 
	$("#ttPopupnewsletter").show();
	$("body#index").addClass("modal-open");
}

function closeDialog(cookies_time)
{  
	var data={'task':'cancelRegisNewsletter', 'cookies_time':cookies_time};        
	if ($('#tt_tick_dont_show').is(':checked')){
        data.notshow = '1';
    }else{
        data.notshow = '0';
    }
		$.ajax({
		type: "POST",
		cache: false,
		url: tt_coupon_url + '/front-end-ajax.php',
		dataType : "json",
		data: data,
		complete: function(){},
		success: function (response) {
			console.log(response);
		}
	});   
	$("#ttPopupnewsletter").hide();
	$("body#index").removeClass("modal-open");
}
function check_email(email){
	emailRegExp = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.([a-z]){2,4})$/;	
	if(emailRegExp.test(email)){
		return true;
	}else{
		return false;
	}
}
function regisNewsletter(){
    var data={'task':'regisNewsletter', 'action':0};
    var email = $("#ttnewsletter-input").val();
    if(check_email(email) == true){
        data.email = email;
        $(".ttAlert").html("");
    }else{
        $(".ttAlert").html(enterEmail);
        return false;
    }
    
    if ($('#tt_tick_dont_show').is(':checked')){
        data.notshow = '1';
    }else{
        data.notshow = '0';
    }
    $.ajax({
		type: "POST",
		cache: false,
		url: tt_coupon_url + '/front-end-ajax.php',
		dataType : "json",
		data: data,
        complete: function(){},
		success: function (response)
		{
			
			if(response.indexOf("@")>0)
			{
				var new_response = response.substring(response.indexOf("@")+1, response.length);
				$(".ttAlert").html('<p class="alert alert-success">'+new_response+'</p>');
			}
			else
			$(".ttAlert").html('<p class="alert alert-warning">'+response+'</p>');
		
			$("#coupon-text-before").hide();
			$("#coupon-text-after").show();
		},
		 error: function(XMLHttpRequest, textStatus, errorThrown) { 
                    alert("Status: " + textStatus); alert("Error: " + errorThrown); 
					
        }  
	});
}